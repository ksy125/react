const First = () => {
  return <div className="w-52 h-52 bg-red-400 flex items-center justify-center"></div>;
};

export default First;
