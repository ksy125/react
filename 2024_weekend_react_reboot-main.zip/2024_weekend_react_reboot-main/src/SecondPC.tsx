const SecondPC = () => {
  return <div className="w-28 h-28 bg-green-500 text-3xl "></div>;
};

export default SecondPC;
