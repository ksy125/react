const Home = () => {
  return <div>홈 페이지</div>;
};

export default Home;
