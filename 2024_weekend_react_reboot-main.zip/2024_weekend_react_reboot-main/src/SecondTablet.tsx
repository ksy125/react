const SecondTablet = () => {
  return <div className="w-28 h-28 bg-blue-500 text-3xl "></div>;
};

export default SecondTablet;
